from aiogram import Bot, Dispatcher, executor, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
import logging

API_TOKEN = '7221366946:AAHZ2dFyJrl3jCS3DPbLSrovjlBsxMnxMAs'

DISPATCHER_GROUP_ID = -1001234567890
OPERATOR_GROUP_ID = -1009876543210

logging.basicConfig(level=logging.INFO)

bot = Bot(token=API_TOKEN, parse_mode='HTML')
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

class Form(StatesGroup):
    name = State()
    phone = State()
    address = State()
    service = State()
    description = State()
    photo = State()
    confirm = State()

main_menu = ReplyKeyboardMarkup(resize_keyboard=True)
main_menu.add(KeyboardButton("Оформить заявку"), KeyboardButton("Связаться с оператором"))

@dp.message_handler(commands='start')
async def start_handler(message: types.Message):
    await message.answer("Здравствуйте! Я бот для оформления заявок на ремонт и изготовление РВД.", reply_markup=main_menu)

@dp.message_handler(lambda message: message.text == "Оформить заявку")
async def start_form(message: types.Message):
    await Form.name.set()
    await message.reply("Введите ваше имя или название компании:")

@dp.message_handler(state=Form.name)
async def process_name(message: types.Message, state: FSMContext):
    await state.update_data(name=message.text)
    await Form.next()
    await message.reply("Укажите номер телефона для связи:")

@dp.message_handler(state=Form.phone)
async def process_phone(message: types.Message, state: FSMContext):
    await state.update_data(phone=message.text)
    await Form.next()
    await message.reply("Введите адрес (если нужен выезд):")

@dp.message_handler(state=Form.address)
async def process_address(message: types.Message, state: FSMContext):
    await state.update_data(address=message.text)
    await Form.next()
    await message.reply("Выберите тип услуги:
1. Изготовление
2. Ремонт
3. Диагностика")

@dp.message_handler(state=Form.service)
async def process_service(message: types.Message, state: FSMContext):
    await state.update_data(service=message.text)
    await Form.next()
    await message.reply("Опишите проблему:")

@dp.message_handler(state=Form.description)
async def process_description(message: types.Message, state: FSMContext):
    await state.update_data(description=message.text)
    await Form.next()
    await message.reply("Прикрепите фото (если есть) или напишите 'нет':")

@dp.message_handler(content_types=['photo', 'text'], state=Form.photo)
async def process_photo(message: types.Message, state: FSMContext):
    data = await state.get_data()
    if message.photo:
        data['photo'] = message.photo[-1].file_id
    else:
        data['photo'] = 'нет'

    summary = (
        f"<b>Новая заявка</b>

"
        f"<b>Имя:</b> {data['name']}
"
        f"<b>Телефон:</b> {data['phone']}
"
        f"<b>Адрес:</b> {data['address']}
"
        f"<b>Услуга:</b> {data['service']}
"
        f"<b>Описание:</b> {data['description']}"
    )
    await state.update_data(summary=summary)
    await Form.confirm.set()
    await message.reply(summary + "\n\nПодтвердите заявку? (Да / Нет)")

@dp.message_handler(lambda msg: msg.text.lower() in ['да', 'нет'], state=Form.confirm)
async def process_confirm(message: types.Message, state: FSMContext):
    data = await state.get_data()
    if message.text.lower() == 'да':
        if data['photo'] != 'нет':
            await bot.send_photo(chat_id=DISPATCHER_GROUP_ID, photo=data['photo'], caption=data['summary'])
        else:
            await bot.send_message(chat_id=DISPATCHER_GROUP_ID, text=data['summary'])
        await message.reply("Спасибо! Ваша заявка отправлена диспетчеру.", reply_markup=main_menu)
    else:
        await message.reply("Заявка отменена.", reply_markup=main_menu)
    await state.finish()

@dp.message_handler(lambda message: message.text == "Связаться с оператором")
async def contact_operator(message: types.Message, state: FSMContext):
    await message.answer("Напишите сообщение, и мы передадим его оператору.")
    await state.set_state("contact_operator")

@dp.message_handler(state="contact_operator")
async def forward_to_operator(message: types.Message, state: FSMContext):
    user = message.from_user
    text = (
        f"<b>Сообщение от клиента</b>
"
        f"<b>Пользователь:</b> @{user.username or user.full_name}
"
        f"<b>ID:</b> {user.id}
"
        f"<b>Сообщение:</b> {message.text}"
    )
    await bot.send_message(chat_id=OPERATOR_GROUP_ID, text=text)
    await message.reply("Ваше сообщение передано оператору. Ожидайте ответа.", reply_markup=main_menu)
    await state.finish()

@dp.message_handler()
async def fallback(message: types.Message):
    await message.reply("Пожалуйста, выберите команду из меню.", reply_markup=main_menu)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)